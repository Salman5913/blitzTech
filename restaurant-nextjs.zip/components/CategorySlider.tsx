"use client";

import Image from "next/image";
import type { Category } from "@/lib/types";

export default function CategorySlider({ categories }: { categories: Category[] }) {
  if (!categories.length) return null;

  return (
    <section id="menu" className="mt-8">
      <div className="mx-auto max-w-7xl px-4">
        <h2 className="text-2xl font-bold mb-4">Categories</h2>
      </div>
      <div className="flex gap-4 overflow-x-auto no-scrollbar px-4 pb-2 md:px-[max(1rem,calc((100vw-80rem)/2+1rem))]">
        {categories.map((cat) => (
          <a
            key={cat.id}
            href={`#category-${cat.slug}`}
            className="flex-shrink-0 w-32 md:w-40 group"
          >
            <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-2xl overflow-hidden shadow-md group-hover:shadow-lg transition">
              <Image
                src={cat.image}
                alt={cat.name}
                fill
                className="object-cover group-hover:scale-105 transition duration-300"
              />
            </div>
            <p className="mt-2 text-center font-semibold text-sm md:text-base group-hover:text-primary transition">
              {cat.name}
            </p>
          </a>
        ))}
      </div>
    </section>
  );
}
