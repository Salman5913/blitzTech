"use client";

import Link from "next/link";
import type { CartItem } from "@/lib/types";
import {
  formatPrice,
  updateCartQty,
  removeFromCart,
  getCartTotal,
} from "@/lib/library";

interface Props {
  open: boolean;
  onClose: () => void;
  items: CartItem[];
}

export default function CartDrawer({ open, onClose, items }: Props) {
  const total = getCartTotal();

  return (
    <>
      {/* overlay */}
      <div
        onClick={onClose}
        className={`fixed inset-0 bg-black/40 z-40 transition-opacity ${
          open ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      />
      {/* panel */}
      <aside
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white z-50 shadow-2xl transform transition-transform duration-300 flex flex-col ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-bold">Your Cart</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-ink text-xl">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {items.length === 0 ? (
            <p className="text-gray-400 text-center mt-10">
              Your cart is empty. Add something tasty! 🍔
            </p>
          ) : (
            items.map(({ product, qty }) => (
              <div key={product.id} className="flex gap-3 items-center border rounded-xl p-3">
                <div className="w-16 h-16 rounded-lg overflow-hidden relative flex-shrink-0 bg-gray-100">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={product.image} alt={product.name} className="object-cover w-full h-full" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{product.name}</p>
                  <p className="text-primary font-bold text-sm">
                    {formatPrice(product.price)}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <button
                      onClick={() => updateCartQty(product.id, qty - 1)}
                      className="w-6 h-6 border rounded-full text-sm hover:border-primary hover:text-primary"
                    >
                      −
                    </button>
                    <span className="text-sm font-semibold w-5 text-center">{qty}</span>
                    <button
                      onClick={() => updateCartQty(product.id, qty + 1)}
                      className="w-6 h-6 border rounded-full text-sm hover:border-primary hover:text-primary"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => removeFromCart(product.id)}
                  className="text-gray-300 hover:text-red-500 text-lg"
                  aria-label="Remove item"
                >
                  🗑
                </button>
              </div>
            ))
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t p-4 space-y-3">
            <div className="flex justify-between font-bold text-lg">
              <span>Subtotal</span>
              <span className="text-primary">{formatPrice(total)}</span>
            </div>
            <Link
              href="/checkout"
              onClick={onClose}
              className="block text-center bg-primary hover:bg-primary-dark text-white font-semibold py-3 rounded-full transition"
            >
              Proceed to Checkout →
            </Link>
          </div>
        )}
      </aside>
    </>
  );
}
