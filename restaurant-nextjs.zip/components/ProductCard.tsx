"use client";

import Image from "next/image";
import type { Product } from "@/lib/types";
import { formatPrice, addToCart, isInCart } from "@/lib/library";
import { useState } from "react";

export default function ProductCard({ product }: { product: Product }) {
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(isInCart(product.id));

  const handleAdd = () => {
    addToCart(product, qty);
    setAdded(true);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm hover:shadow-md transition overflow-hidden flex flex-col">
      <div className="relative h-44 w-full">
        <Image
          src={product.image}
          alt={product.name}
          fill
          className="object-cover"
        />
        {product.tag && (
          <span className="absolute top-3 left-3 bg-primary text-white text-xs font-bold px-2.5 py-1 rounded-full">
            {product.tag}
          </span>
        )}
      </div>
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-bold text-base leading-snug">{product.name}</h3>
        <p className="text-sm text-gray-500 mt-1 line-clamp-2 flex-1">
          {product.description}
        </p>
        <p className="mt-2 font-extrabold text-primary">
          {formatPrice(product.price)}
        </p>

        <div className="mt-3 flex items-center gap-2">
          <div className="flex items-center border border-gray-200 rounded-full">
            <button
              onClick={() => setQty((q) => Math.max(1, q - 1))}
              className="px-3 py-1.5 text-gray-500 hover:text-primary"
              aria-label="Decrease quantity"
            >
              −
            </button>
            <span className="w-6 text-center text-sm font-semibold">{qty}</span>
            <button
              onClick={() => setQty((q) => q + 1)}
              className="px-3 py-1.5 text-gray-500 hover:text-primary"
              aria-label="Increase quantity"
            >
              +
            </button>
          </div>
          <button
            onClick={handleAdd}
            className={`flex-1 text-sm font-semibold px-4 py-2 rounded-full transition ${
              added
                ? "bg-green-600 text-white"
                : "bg-ink text-white hover:bg-primary"
            }`}
          >
            {added ? "✓ Added" : "Add to Cart"}
          </button>
        </div>
      </div>
    </div>
  );
}
