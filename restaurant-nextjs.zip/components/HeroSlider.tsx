"use client";

import Image from "next/image";
import type { HeroSlide } from "@/lib/types";
import { useEffect, useState } from "react";

export default function HeroSlider({ slides }: { slides: HeroSlide[] }) {
  const [index, setIndex] = useState(0);

  // auto-advance every 5 seconds
  useEffect(() => {
    if (slides.length <= 1) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % slides.length), 5000);
    return () => clearInterval(t);
  }, [slides.length]);

  if (!slides.length) return null;
  const slide = slides[index];

  return (
    <section className="relative h-[420px] md:h-[520px] overflow-hidden">
      {slides.map((s, i) => (
        <div
          key={s.id}
          className={`absolute inset-0 transition-opacity duration-700 ${
            i === index ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          <Image
            src={s.image}
            alt={s.title}
            fill
            priority={i === 0}
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
          <div className="relative z-10 mx-auto max-w-7xl h-full px-4 flex flex-col justify-center">
            <h1 className="text-white text-4xl md:text-6xl font-extrabold max-w-xl leading-tight">
              {s.title}
            </h1>
            <p className="text-white/85 mt-4 max-w-md text-base md:text-lg">
              {s.subtitle}
            </p>
            <a
              href="#menu"
              className="mt-6 inline-flex w-fit bg-primary hover:bg-primary-dark text-white font-semibold px-6 py-3 rounded-full transition"
            >
              {s.ctaText}
            </a>
          </div>
        </div>
      ))}

      {/* dots */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setIndex(i)}
            aria-label={`Slide ${i + 1}`}
            className={`h-2.5 rounded-full transition-all ${
              i === index ? "w-8 bg-white" : "w-2.5 bg-white/50"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
