"use client";

import Link from "next/link";
import { useCart, getCartCount, formatPrice, getCartTotal } from "@/lib/library";
import CartDrawer from "./CartDrawer";
import { useState } from "react";

export default function Header() {
  const cart = useCart();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const count = getCartCount();
  const total = getCartTotal();

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-gray-100 shadow-sm">
        <div className="mx-auto max-w-7xl px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl">🍽️</span>
            <span className="text-xl font-extrabold tracking-tight text-primary">
              Restaurant
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
            <Link href="/" className="hover:text-primary">Home</Link>
            <a href="#popular" className="hover:text-primary">Popular</a>
            <a href="#deals" className="hover:text-primary">Deals</a>
            <a href="#menu" className="hover:text-primary">Menu</a>
          </nav>

          <button
            onClick={() => setDrawerOpen(true)}
            className="relative flex items-center gap-2 bg-primary text-white text-sm font-semibold px-4 py-2 rounded-full hover:bg-primary-dark transition"
          >
            🛒 Cart
            {count > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-ink text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {count}
              </span>
            )}
          </button>
        </div>
        {count > 0 && (
          <div className="bg-ink text-white text-center text-xs py-1">
            {formatPrice(total)} — <span className="underline cursor-pointer" onClick={() => setDrawerOpen(true)}>view cart</span>
          </div>
        )}
      </header>

      <CartDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} items={cart} />
    </>
  );
}
