"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  useCart,
  formatPrice,
  getCartTotal,
  checkoutCart,
  updateCartQty,
  removeFromCart,
} from "@/lib/library";

export default function CheckoutForm() {
  const cart = useCart();
  const router = useRouter();
  const total = getCartTotal();
  const [form, setForm] = useState({ name: "", phone: "", address: "", notes: "" });
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
  const [orderId, setOrderId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = checkoutCart({
      name: form.name,
      phone: form.phone,
      address: form.address,
      notes: form.notes,
    });
    if (result.success) {
      setOrderId(result.orderId);
      setStatus("success");
    } else {
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <div className="text-center py-16">
        <p className="text-6xl mb-4">🎉</p>
        <h2 className="text-2xl font-extrabold">Order Placed!</h2>
        <p className="text-gray-500 mt-2">
          Your order <span className="font-bold text-primary">{orderId}</span> has been
          received. We will call you shortly to confirm.
        </p>
        <button
          onClick={() => router.push("/")}
          className="mt-6 bg-primary text-white font-semibold px-6 py-3 rounded-full hover:bg-primary-dark transition"
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-8">
      {/* delivery details */}
      <div className="space-y-4">
        <h2 className="font-bold text-lg">Delivery Details</h2>
        {status === "error" && (
          <p className="text-sm text-red-600 bg-red-50 rounded-lg px-3 py-2">
            Your cart is empty. Add items before checking out.
          </p>
        )}
        <input
          required
          placeholder="Full name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <input
          required
          placeholder="Phone number"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          className="w-full border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <textarea
          required
          placeholder="Delivery address"
          rows={3}
          value={form.address}
          onChange={(e) => setForm({ ...form, address: e.target.value })}
          className="w-full border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
        />
        <textarea
          placeholder="Order notes (optional)"
          rows={2}
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          className="w-full border rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {/* order summary */}
      <div>
        <h2 className="font-bold text-lg mb-4">Order Summary</h2>
        <div className="bg-white rounded-2xl shadow-sm p-4 space-y-3">
          {cart.length === 0 ? (
            <p className="text-gray-400 text-sm">Cart is empty.</p>
          ) : (
            cart.map(({ product, qty }) => (
              <div key={product.id} className="flex items-center justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <p className="font-medium truncate">{product.name}</p>
                  <div className="flex items-center gap-2 text-gray-500">
                    <button type="button" onClick={() => updateCartQty(product.id, qty - 1)} className="hover:text-primary">−</button>
                    <span>× {qty}</span>
                    <button type="button" onClick={() => updateCartQty(product.id, qty + 1)} className="hover:text-primary">+</button>
                    <button type="button" onClick={() => removeFromCart(product.id)} className="hover:text-red-500 ml-1">🗑</button>
                  </div>
                </div>
                <span className="font-semibold whitespace-nowrap">
                  {formatPrice(product.price * qty)}
                </span>
              </div>
            ))
          )}
          <div className="border-t pt-3 flex justify-between font-extrabold">
            <span>Total</span>
            <span className="text-primary">{formatPrice(total)}</span>
          </div>
        </div>
        <button
          type="submit"
          disabled={cart.length === 0}
          className="mt-4 w-full bg-primary hover:bg-primary-dark disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold py-3 rounded-full transition"
        >
          Place Order — {formatPrice(total)}
        </button>
      </div>
    </form>
  );
}
