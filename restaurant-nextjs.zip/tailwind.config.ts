import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#D72631",
          dark: "#A81B24",
          light: "#FBE9EA",
        },
        ink: "#1F2430",
        cream: "#FFF8F0",
      },
    },
  },
  plugins: [],
};

export default config;
