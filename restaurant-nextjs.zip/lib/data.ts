import type { HomePageData, Product } from "./types";

/**
 * SAMPLE DATA — this is what the API will eventually return.
 * Shape matches: { heroSlides, popularItems, deals, categories }
 * When backend is live replace the bodies below with apiGet() calls,
 * e.g. return apiGet<HomePageData>("/home");
 */

const U = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=800&q=80`;

export async function getHomePageData(): Promise<HomePageData> {
  // ---- FIRST SECTION: dynamic hero slider ----
  const heroSlides = [
    {
      id: 1,
      title: "Handcrafted Desi BBQ",
      subtitle: "Charcoal grilled, marinated overnight in our secret spices.",
      image: U("photo-1555939594-58d7cb561ad1"),
      ctaText: "Order Now",
    },
    {
      id: 2,
      title: "Stone-Baked Pizzas",
      subtitle: "Fresh dough, real mozzarella, fired at 400 degrees.",
      image: U("photo-1513104890138-7c749659a591"),
      ctaText: "Explore Pizzas",
    },
    {
      id: 3,
      title: "Royal Chicken Biryani",
      subtitle: "Aged basmati layered with saffron and slow-cooked chicken.",
      image: U("photo-1631452180519-c014fe946bc7"),
      ctaText: "Try Biryani",
    },
  ];

  // ---- SECOND SECTION: popular items ----
  const popularItems: Product[] = [
    {
      id: 101,
      name: "Chicken Tikka Pizza",
      description: "Tikka chunks, onions, mozzarella on a stone-baked crust.",
      price: 1299,
      image: U("photo-1513104890138-7c749659a591"),
      tag: "Bestseller",
    },
    {
      id: 102,
      name: "Special Chicken Biryani",
      description: "Fragrant basmati, spicy masala, served with raita.",
      price: 549,
      image: U("photo-1631452180519-c014fe946bc7"),
      tag: "Most Ordered",
    },
    {
      id: 103,
      name: "Zinger Burger",
      description: "Crispy fillet, signature sauce, toasted brioche bun.",
      price: 649,
      image: U("photo-1568901346375-23c9450c58cd"),
      tag: "Fan Favorite",
    },
    {
      id: 104,
      name: "Malai Boti Platter",
      description: "Creamy grilled cubes with naan and mint chutney.",
      price: 1199,
      image: U("photo-1603894584373-5ac82b2ae398"),
      tag: "Chef Special",
    },
  ];

  // ---- THIRD SECTION: deals ----
  const deals: Product[] = [
    {
      id: 201,
      name: "Family Feast Deal",
      description: "2 large pizzas, 1.5L drink and garlic bread. Serves 4.",
      price: 2999,
      image: U("photo-1565299624946-b28f40a0ae38"),
      tag: "Save 25%",
    },
    {
      id: 202,
      name: "Burger Duo Deal",
      description: "2 zinger burgers + large fries + 2 drinks.",
      price: 1499,
      image: U("photo-1571091718767-18b5b1457add"),
      tag: "Save 20%",
    },
    {
      id: 203,
      name: "BBQ Night Deal",
      description: "Malai boti, seekh kebabs, 4 naans and raita.",
      price: 2499,
      image: U("photo-1555939594-58d7cb561ad1"),
      tag: "Weekend Only",
    },
  ];

  // ---- DYNAMIC CATEGORIES + PRODUCTS ----
  const categories = [
    {
      id: 1,
      name: "Pizzas",
      slug: "pizzas",
      image: U("photo-1513104890138-7c749659a591"),
      products: [
        { id: 301, name: "Chicken Tikka Pizza", description: "Spicy tikka, onions, mozzarella.", price: 1299, image: U("photo-1513104890138-7c749659a591") },
        { id: 302, name: "Fajita Pizza", description: "Smoky fajita chicken, capsicum, olives.", price: 1399, image: U("photo-1565299624946-b28f40a0ae38") },
        { id: 303, name: "Cheese Lovers", description: "Triple cheese blend overload.", price: 1199, image: U("photo-1574071318508-1cdbab80d002") },
        { id: 304, name: "Veggie Supreme", description: "Mushrooms, corn, peppers, onions.", price: 1099, image: U("photo-1571407970349-bc81e7e96d47") },
      ] as Product[],
    },
    {
      id: 2,
      name: "Burgers",
      slug: "burgers",
      image: U("photo-1568901346375-23c9450c58cd"),
      products: [
        { id: 401, name: "Zinger Burger", description: "Crispy spicy fillet with signature sauce.", price: 649, image: U("photo-1568901346375-23c9450c58cd") },
        { id: 402, name: "Beef Smash Burger", description: "Double smashed patty, cheddar, pickles.", price: 899, image: U("photo-1553979459-d2229ba7433b") },
        { id: 403, name: "Chicken Patty Melt", description: "Grilled patty, caramelized onions, cheese.", price: 749, image: U("photo-1550547660-d9450f859349") },
        { id: 404, name: "Loaded Fries", description: "Crispy fries topped with cheese sauce.", price: 499, image: U("photo-1573080496219-bb080dd4f877") },
      ] as Product[],
    },
    {
      id: 3,
      name: "BBQ & Grills",
      slug: "bbq-grills",
      image: U("photo-1555939594-58d7cb561ad1"),
      products: [
        { id: 501, name: "Malai Boti", description: "Creamy marinated grilled chicken cubes.", price: 1199, image: U("photo-1603894584373-5ac82b2ae398") },
        { id: 502, name: "Seekh Kebab (4 pc)", description: "Hand-rolled minced beef kebabs.", price: 799, image: U("photo-1555939594-58d7cb561ad1") },
        { id: 503, name: "BBQ Platter", description: "Assorted grills with naan and chutneys.", price: 2299, image: U("photo-1544025162-d76694265947") },
        { id: 504, name: "Grilled Wings (6 pc)", description: "Charcoal wings in peri peri glaze.", price: 899, image: U("photo-1527477396000-e27163b481c2") },
      ] as Product[],
    },
    {
      id: 4,
      name: "Desserts",
      slug: "desserts",
      image: U("photo-1551024506-0bccd828d307"),
      products: [
        { id: 601, name: "Molten Lava Cake", description: "Warm chocolate cake with a gooey center.", price: 449, image: U("photo-1551024506-0bccd828d307") },
        { id: 602, name: "Gulab Jamun (4 pc)", description: "Soft khoya dumplings in rose syrup.", price: 349, image: U("photo-1551024506-0bccd828d307") },
        { id: 603, name: "Cheesecake Slice", description: "Baked New York style with berry compote.", price: 549, image: U("photo-1533134242443-d4fd215305ad") },
        { id: 604, name: "Kulfi Falooda", description: "Traditional kulfi with vermicelli and basil seeds.", price: 399, image: U("photo-1563805042-7684c019e1cb") },
      ] as Product[],
    },
  ];

  return { heroSlides, popularItems, deals, categories };
}

/** Helper: flatten every product across all categories (used by search). */
export function flattenProducts(data: HomePageData): Product[] {
  return data.categories.flatMap((c) => c.products);
}
