"use client";

/**
 * Cart & Checkout library.
 * ALL cart reads/writes go through this file.
 * Cart data is stored in localStorage BASE64-ENCODED (never raw).
 */

import { useEffect, useState } from "react";
import type { CartItem, CheckoutDetails, Product } from "./types";

const CART_KEY = "restaurant_cart_b64";
const ORDER_KEY = "restaurant_last_order_b64";
const CART_EVENT = "cart-updated";

/* ---------- encoding helpers ---------- */

export function encodeCart(data: unknown): string {
  return btoa(unescape(encodeURIComponent(JSON.stringify(data))));
}

export function decodeCart<T>(encoded: string): T | null {
  try {
    return JSON.parse(decodeURIComponent(escape(atob(encoded)))) as T;
  } catch {
    return null;
  }
}

/* ---------- internal: save + notify ---------- */

function saveCart(items: CartItem[]): void {
  localStorage.setItem(CART_KEY, encodeCart(items));
  window.dispatchEvent(new Event(CART_EVENT));
}

/* ---------- READ: always use this to get decoded cart data ---------- */

export function getCart(): CartItem[] {
  if (typeof window === "undefined") return [];
  const raw = localStorage.getItem(CART_KEY);
  if (!raw) return [];
  return decodeCart<CartItem[]>(raw) ?? [];
}

export function getCartCount(): number {
  return getCart().reduce((sum, item) => sum + item.qty, 0);
}

export function getCartTotal(): number {
  return getCart().reduce((sum, item) => sum + item.qty * item.product.price, 0);
}

export function isInCart(productId: number): boolean {
  return getCart().some((item) => item.product.id === productId);
}

/* ---------- WRITE: every mutation in the cart goes through these ---------- */

export function addToCart(product: Product, qty: number = 1): void {
  const cart = getCart();
  const existing = cart.find((item) => item.product.id === product.id);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({ product, qty });
  }
  saveCart(cart);
}

export function updateCartQty(productId: number, qty: number): void {
  let cart = getCart();
  if (qty <= 0) {
    cart = cart.filter((item) => item.product.id !== productId);
  } else {
    const item = cart.find((i) => i.product.id === productId);
    if (item) item.qty = qty;
  }
  saveCart(cart);
}

export function removeFromCart(productId: number): void {
  saveCart(getCart().filter((item) => item.product.id !== productId));
}

export function clearCart(): void {
  saveCart([]);
}

/* ---------- CHECKOUT ---------- */

export function checkoutCart(
  details: CheckoutDetails
): { success: boolean; orderId: string | null } {
  const cart = getCart();
  if (cart.length === 0) return { success: false, orderId: null };

  const orderId = `ORD-${Date.now()}`;
  const order = {
    orderId,
    items: cart,
    total: getCartTotal(),
    ...details,
    placedAt: new Date().toISOString(),
  };

  localStorage.setItem(ORDER_KEY, encodeCart(order));
  clearCart();
  return { success: true, orderId };
}

export function getLastOrder<T>(): T | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(ORDER_KEY);
  return raw ? decodeCart<T>(raw) : null;
}

/* ---------- REACT HOOK: subscribe to cart changes ---------- */

export function useCart(): CartItem[] {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const refresh = () => setItems(getCart());
    refresh();
    window.addEventListener(CART_EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(CART_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  return items;
}

/* ---------- misc ---------- */

export function formatPrice(price: number): string {
  return `Rs. ${price.toLocaleString("en-PK")}`;
}
