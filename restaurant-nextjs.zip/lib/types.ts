export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  tag?: string;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  image: string;
  products: Product[];
}

export interface HeroSlide {
  id: number;
  title: string;
  subtitle: string;
  image: string;
  ctaText: string;
}

export interface HomePageData {
  heroSlides: HeroSlide[];
  popularItems: Product[];
  deals: Product[];
  categories: Category[];
}

export interface CartItem {
  product: Product;
  qty: number;
}

export interface CheckoutDetails {
  name: string;
  phone: string;
  address: string;
  notes?: string;
}
