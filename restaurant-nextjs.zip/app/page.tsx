import { getHomePageData, flattenProducts } from "@/lib/data";
import Header from "@/components/Header";
import HeroSlider from "@/components/HeroSlider";
import CategorySlider from "@/components/CategorySlider";
import SearchBar from "@/components/SearchBar";
import PopularItems from "@/components/PopularItems";
import DealsSection from "@/components/DealsSection";
import CategorySection from "@/components/CategorySection";
import Footer from "@/components/Footer";

export default async function Home() {
  // API-driven data (currently sample data — swap lib/data.ts bodies with apiGet later)
  const data = await getHomePageData();
  const allProducts = flattenProducts(data);

  return (
    <>
      <Header />
      <main className="pb-16">
        {/* SECTION 1 — dynamic hero slider */}
        <HeroSlider slides={data.heroSlides} />

        {/* Category slider (after first section) */}
        <CategorySlider categories={data.categories} />

        {/* Search bar (after category slider) */}
        <SearchBar products={allProducts} />

        {/* SECTION 2 — popular items (dynamic) */}
        <PopularItems items={data.popularItems} />

        {/* SECTION 3 — deals (dynamic) */}
        <DealsSection deals={data.deals} />

        {/* ALL REMAINING SECTIONS — dynamic categories + their products */}
        {data.categories.map((category) => (
          <CategorySection key={category.id} category={category} />
        ))}
      </main>
      <Footer />
    </>
  );
}
