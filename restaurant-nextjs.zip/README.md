# Restaurant — Next.js + TypeScript + Tailwind

Dynamic food-ordering website. All sections (hero slider, popular items, deals,
categories + products) are driven by data variables that will later come from APIs.

## Structure

- `app/page.tsx` — home page, assembles all section components
- `app/checkout/page.tsx` — checkout flow
- `components/` — one component per section:
  - `HeroSlider` (section 1), `PopularItems` (section 2), `DealsSection` (section 3),
    `CategorySection` (dynamic categories), `ProductCard` (used everywhere),
    `CategorySlider`, `SearchBar`, `Header`, `Footer`, `CartDrawer`, `CheckoutForm`
- `lib/data.ts` — sample data (swap bodies with `apiGet()` from `lib/fetcher.ts` when backend is ready)
- `lib/fetcher.ts` — GET/POST/PUT/DELETE API helpers
- `lib/library.ts` — cart + checkout library (localStorage, base64-encoded)

## Run locally

```bash
npm install
npm run dev
# open http://localhost:3000
```
